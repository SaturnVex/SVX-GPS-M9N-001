@echo off
REM SPDX-License-Identifier: BSD-3-Clause
REM Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
REM ==== One-time environment setup for gps_test.py on a fresh Windows PC ====
cd /d "%~dp0"

echo [1/3] Checking Python ...
set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY (
    where python >nul 2>nul && python -c "import sys" >nul 2>nul && set PY=python
)
if not defined PY (
    echo     Python not found. Installing with winget ...
    where winget >nul 2>nul || (
        echo     winget is not available. Download Python from https://www.python.org/downloads/windows/
        echo     During install, TICK "Add python.exe to PATH", then run setup.bat again.
        pause & exit /b 1
    )
    winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
    echo.
    echo     Python installed. CLOSE this window and run setup.bat again to continue.
    pause & exit /b 0
)
%PY% --version

echo [2/3] Installing pyserial (from the bundled pkgs folder, no Internet needed) ...
%PY% -m pip install --disable-pip-version-check --no-index --find-links "%~dp0pkgs" pyserial
if errorlevel 1 (
    echo     Offline install failed, trying online ...
    %PY% -m ensurepip --upgrade >nul 2>nul
    %PY% -m pip install --disable-pip-version-check pyserial || (echo     pyserial install failed & pause & exit /b 1)
)
%PY% -c "import serial; print('    pyserial', serial.__version__, 'OK')" || (echo     pyserial is not usable & pause & exit /b 1)

echo [3/3] Available COM ports:
%PY% gps_test.py --list
echo.
echo Done. Connect the USB-UART adapter to the board, then run:  run.bat
pause
