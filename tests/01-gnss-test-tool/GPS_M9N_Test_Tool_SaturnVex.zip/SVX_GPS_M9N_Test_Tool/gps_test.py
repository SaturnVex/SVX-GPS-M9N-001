#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
gps_test.py - NEO-M9N GPS parameter test over UART on Windows.

Board SVX-GPS-M9N-001. Wiring (header H2, 2 x 5 pins, 2.54 mm):
    H2 pin 5   UART_TX (NEO-M9N TX)  -> RX of 3.3V USB-UART adapter
    H2 pin 7   UART_RX (NEO-M9N RX)  -> TX of 3.3V USB-UART adapter
    H2 pin 9   GND                   -> GND
    H2 pin 1/3 VIN (max 5.5V)        -> 5V of USB-UART (U5 AP2112K regulates to 3V3)
NEO-M9N default: UART1 = 38400 baud, NMEA output.

Requires: pip install pyserial
Examples:
    python gps_test.py                       # auto-detect COM port + baud
    python gps_test.py -p COM5 -b 38400
    python gps_test.py -p COM5 --reset cold  # measure cold-start TTFF
    python gps_test.py -p COM5 -t 600 --raw log.ubx   # run 10 min, save raw stream (opens in u-center)
    python gps_test.py --replay log.ubx      # re-analyse a raw log file
"""
import argparse
import csv
import math
import os
import statistics
import struct
import sys
import time
from datetime import datetime

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None

BAUDS = [38400, 9600, 115200, 230400, 460800, 921600]
TALKER = {"GP": "GPS", "GL": "GLONASS", "GA": "Galileo", "GB": "BeiDou",
          "BD": "BeiDou", "GQ": "QZSS", "GN": "GNSS"}
SYSID = {1: "GPS", 2: "GLONASS", 3: "Galileo", 4: "BeiDou", 5: "QZSS", 6: "NavIC"}
GGA_QUALITY = {0: "No fix", 1: "GPS fix", 2: "DGPS", 4: "RTK fixed", 5: "RTK float", 6: "Dead reckoning"}
PVT_FIX = {0: "No fix", 1: "DR only", 2: "2D", 3: "3D", 4: "GNSS+DR", 5: "Time only"}


# ---------------------------------------------------------------- UBX helpers
def ubx_frame(cls, mid, payload=b""):
    body = bytes([cls, mid]) + struct.pack("<H", len(payload)) + payload
    a = b = 0
    for x in body:
        a = (a + x) & 0xFF
        b = (b + a) & 0xFF
    return b"\xb5\x62" + body + bytes([a, b])


def ubx_valset_u1(key, value):
    # CFG-VALSET, version 0, RAM layer only (flash is not touched)
    payload = struct.pack("<BBH", 0, 0x01, 0) + struct.pack("<IB", key, value)
    return ubx_frame(0x06, 0x8A, payload)


UBX_MON_VER_POLL = ubx_frame(0x0A, 0x04)
KEY_MSGOUT_NAV_PVT_UART1 = 0x20910007
RESET_MASK = {"hot": 0x0000, "warm": 0x0001, "cold": 0xFFFF}


def ubx_reset(kind):
    # CFG-RST, resetMode 0x02 = controlled GNSS-only reset
    return ubx_frame(0x06, 0x04, struct.pack("<HBB", RESET_MASK[kind], 0x02, 0))


# ---------------------------------------------------------------- stream parser
class StreamParser:
    """Splits NMEA ($...\\r\\n) and UBX (B5 62 ...) messages out of a byte stream."""

    def __init__(self):
        self.buf = bytearray()
        self.nmea_bad = 0
        self.ubx_bad = 0

    def feed(self, data):
        self.buf += data
        out = []
        while True:
            i_n = self.buf.find(b"$")
            i_u = self.buf.find(b"\xb5\x62")
            cands = [i for i in (i_n, i_u) if i >= 0]
            if not cands:
                # keep the last byte in case a B5 62 header was split
                del self.buf[:-1]
                break
            i = min(cands)
            del self.buf[:i]
            if self.buf[:1] == b"$":
                end = self.buf.find(b"\n")
                if end < 0:
                    if len(self.buf) > 200:  # garbage
                        del self.buf[:1]
                        continue
                    break
                line = bytes(self.buf[:end]).strip()
                del self.buf[:end + 1]
                s = self._check_nmea(line)
                if s:
                    out.append(("NMEA", s))
                else:
                    self.nmea_bad += 1
            else:
                if len(self.buf) < 6:
                    break
                ln = struct.unpack_from("<H", self.buf, 4)[0]
                if ln > 4096:
                    del self.buf[:2]
                    self.ubx_bad += 1
                    continue
                if len(self.buf) < 8 + ln:
                    break
                frame = bytes(self.buf[:8 + ln])
                if ubx_frame(frame[2], frame[3], frame[6:6 + ln]) == frame:
                    out.append(("UBX", (frame[2], frame[3], frame[6:6 + ln])))
                    del self.buf[:8 + ln]
                else:
                    self.ubx_bad += 1
                    del self.buf[:2]
        return out

    @staticmethod
    def _check_nmea(line):
        try:
            s = line.decode("ascii")
        except UnicodeDecodeError:
            return None
        if "*" not in s:
            return None
        body, cs = s[1:].rsplit("*", 1)
        c = 0
        for ch in body:
            c ^= ord(ch)
        try:
            return body if int(cs[:2], 16) == c else None
        except ValueError:
            return None


# ---------------------------------------------------------------- GNSS state
def _f(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _i(x, default=None):
    try:
        return int(x)
    except (TypeError, ValueError):
        return default


def nmea_latlon(v, hemi):
    if not v:
        return None
    d = float(v)
    deg = int(d // 100)
    val = deg + (d - deg * 100) / 60.0
    return -val if hemi in ("S", "W") else val


class GnssState:
    def __init__(self):
        self.t0 = time.monotonic()
        self.ttff = None
        self.msg_count = {}
        self.utc = self.date = None
        self.lat = self.lon = self.alt = self.geoid = None
        self.quality = 0
        self.num_sv_used = None
        self.hdop = self.pdop = self.vdop = None
        self.fix_type = None          # GSA 1/2/3
        self.rmc_status = None
        self.speed_kmh = self.course = None
        self.used_by_sys = {}         # sysId -> set(svid)
        self._gsa_acc = {}
        self.sats = {}                # (talker, svid, sig) -> (elev, az, cno, t)
        self.pvt = None
        self.mon_ver = None
        self.txt = []
        self.fixes = []               # (lat, lon, alt)
        self.epochs = 0
        self.new_epoch = False

    def restart_ttff(self):
        self.t0 = time.monotonic()
        self.ttff = None
        self.fixes.clear()

    def _got_fix(self):
        if self.ttff is None:
            self.ttff = time.monotonic() - self.t0

    # ---- NMEA
    def handle_nmea(self, s):
        f = s.split(",")
        talker, typ = f[0][:2], f[0][2:]
        self.msg_count[f[0]] = self.msg_count.get(f[0], 0) + 1
        h = getattr(self, "_nmea_" + typ, None)
        if h:
            try:
                h(talker, f)
            except (ValueError, IndexError):
                pass

    def _nmea_GGA(self, talker, f):
        self.utc = f[1]
        self.quality = _i(f[6], 0)
        self.num_sv_used = _i(f[7])
        self.hdop = _f(f[8])
        if self.quality > 0:
            self.lat = nmea_latlon(f[2], f[3])
            self.lon = nmea_latlon(f[4], f[5])
            self.alt = _f(f[9])
            self.geoid = _f(f[11])
            self._got_fix()
            self.fixes.append((self.lat, self.lon, self.alt))
        self.epochs += 1
        self.new_epoch = True
        # NEO-M9N sends GSA after GGA: commit the used-satellite list of the previous epoch
        if self._gsa_acc:
            self.used_by_sys = self._gsa_acc
        self._gsa_acc = {}

    def _nmea_RMC(self, talker, f):
        self.utc = f[1]
        self.rmc_status = f[2]
        if f[7]:
            self.speed_kmh = float(f[7]) * 1.852
        self.course = _f(f[8])
        self.date = f[9]

    def _nmea_GSA(self, talker, f):
        self.fix_type = _i(f[2])
        svs = {int(x) for x in f[3:15] if x}
        self.pdop, self.hdop, self.vdop = _f(f[15]), _f(f[16]), _f(f[17])
        sysid = _i(f[18]) if len(f) > 18 else None
        if sysid is None:
            sysid = {"GP": 1, "GL": 2, "GA": 3, "GB": 4, "BD": 4, "GQ": 5}.get(talker, 0)
        self._gsa_acc.setdefault(sysid, set()).update(svs)

    def _nmea_GSV(self, talker, f):
        now = time.monotonic()
        n = len(f) - 4
        sig = f[-1] if n % 4 == 1 else ""
        groups = (n - (1 if sig else 0)) // 4
        for g in range(groups):
            svid, el, az, cno = f[4 + g * 4: 8 + g * 4]
            if svid:
                self.sats[(talker, int(svid), sig)] = (_i(el), _i(az), _i(cno), now)

    def _nmea_TXT(self, talker, f):
        self.txt.append(f[4] if len(f) > 4 else ",".join(f))
        self.txt = self.txt[-5:]

    # ---- UBX
    def handle_ubx(self, cls, mid, p):
        key = "UBX-%02X-%02X" % (cls, mid)
        self.msg_count[key] = self.msg_count.get(key, 0) + 1
        if (cls, mid) == (0x01, 0x07) and len(p) >= 92:
            (itow, year, month, day, hour, minute, sec, valid, tacc, nano, fix, flags,
             flags2, numsv, lon, lat, height, hmsl, hacc, vacc, veln, vele, veld,
             gspeed, headmot, sacc, headacc, pdop) = struct.unpack_from(
                "<IHBBBBBBIiBBBBiiiiIIiiiiiIIH", p, 0)
            self.pvt = dict(fix=fix, gnss_ok=bool(flags & 1), numsv=numsv,
                            hacc=hacc / 1000, vacc=vacc / 1000, sacc=sacc / 1000,
                            tacc=tacc, pdop=pdop / 100, gspeed=gspeed / 1000,
                            veld=veld / 1000, t=time.monotonic())
        elif (cls, mid) == (0x0A, 0x04):
            sw = p[0:30].split(b"\0")[0].decode(errors="ignore")
            hw = p[30:40].split(b"\0")[0].decode(errors="ignore")
            ext = [p[i:i + 30].split(b"\0")[0].decode(errors="ignore")
                   for i in range(40, len(p), 30)]
            self.mon_ver = [f"SW: {sw}", f"HW: {hw}"] + ext

    # ---- derived
    def visible_sats(self, max_age=3.0):
        now = time.monotonic()
        return {k: v for k, v in self.sats.items() if now - v[3] <= max_age}

    def used_count(self):
        return sum(len(v) for v in self.used_by_sys.values())

    def cno_stats(self):
        vals = [v[2] for v in self.visible_sats().values() if v[2]]
        if not vals:
            return None
        vals.sort(reverse=True)
        top4 = vals[:4]
        return dict(n=len(vals), max=vals[0], mean=sum(vals) / len(vals),
                    top4=sum(top4) / len(top4))


# ---------------------------------------------------------------- statistics
def position_stats(fixes):
    if len(fixes) < 2:
        return None
    lat0 = statistics.fmean(x[0] for x in fixes)
    lon0 = statistics.fmean(x[1] for x in fixes)
    alts = [x[2] for x in fixes if x[2] is not None]
    R = 6378137.0
    k = math.cos(math.radians(lat0))
    d = sorted(math.hypot(math.radians(la - lat0) * R, math.radians(lo - lon0) * R * k)
               for la, lo, _ in fixes)

    def pct(p):
        return d[min(len(d) - 1, int(round(p * (len(d) - 1))))]

    drms = math.sqrt(sum(x * x for x in d) / len(d))
    return dict(n=len(fixes), lat=lat0, lon=lon0,
                alt=statistics.fmean(alts) if alts else None,
                alt_std=statistics.pstdev(alts) if len(alts) > 1 else None,
                cep50=pct(0.5), cep95=pct(0.95), drms2=2 * drms, max=d[-1])


# ---------------------------------------------------------------- display
def fmt(v, spec="", none="--"):
    return none if v is None else format(v, spec)


def render(st, parser, port_desc):
    L = []
    el = time.monotonic() - st.t0
    L.append(f"=== NEO-M9N GPS TEST === {port_desc}   elapsed: {el:6.0f}s   (Ctrl+C to stop)")
    if st.mon_ver:
        L.append("  " + " | ".join(st.mon_ver[:4]))
    L.append("")
    utc = st.utc or ""
    utc_s = f"{utc[0:2]}:{utc[2:4]}:{utc[4:]}" if len(utc) >= 6 else "--"
    date = st.date or ""
    date_s = f"20{date[4:6]}-{date[2:4]}-{date[0:2]}" if len(date) == 6 else "--"
    fixname = GGA_QUALITY.get(st.quality, str(st.quality))
    ft = {1: "No fix", 2: "2D", 3: "3D"}.get(st.fix_type, "--")
    L.append(f" UTC        : {date_s} {utc_s}")
    L.append(f" Fix        : {fixname}  ({ft})   RMC status: {st.rmc_status or '--'}")
    L.append(f" TTFF       : {fmt(st.ttff, '.1f')} s")
    L.append(f" Latitude   : {fmt(st.lat, '.7f')}")
    L.append(f" Longitude  : {fmt(st.lon, '.7f')}")
    L.append(f" Alt (MSL)  : {fmt(st.alt, '.1f')} m   (geoid sep {fmt(st.geoid, '.1f')} m)")
    L.append(f" Speed      : {fmt(st.speed_kmh, '.2f')} km/h   Course: {fmt(st.course, '.1f')} deg")
    L.append(f" DOP        : PDOP {fmt(st.pdop, '.2f')}  HDOP {fmt(st.hdop, '.2f')}  VDOP {fmt(st.vdop, '.2f')}")
    if st.pvt and time.monotonic() - st.pvt["t"] < 3:
        p = st.pvt
        L.append(f" UBX-NAV-PVT: fix {PVT_FIX.get(p['fix'], p['fix'])}  numSV {p['numsv']}  "
                 f"hAcc {p['hacc']:.2f} m  vAcc {p['vacc']:.2f} m  sAcc {p['sacc']:.2f} m/s  tAcc {p['tacc']} ns")
    vis = st.visible_sats()
    L.append(f" Satellites : used {st.used_count()} (GGA: {fmt(st.num_sv_used)})   "
             f"visible {len({(k[0], k[1]) for k in vis})}")
    by = {}
    for (tk, svid, sig), v in vis.items():
        by.setdefault(TALKER.get(tk, tk), []).append((svid, sig, v))
    used_all = {SYSID.get(k, "?"): v for k, v in st.used_by_sys.items()}
    for name in sorted(by):
        lst = sorted(by[name], key=lambda x: (x[0], x[1]))
        used = used_all.get(name, set())
        cells = []
        for svid, sig, (elv, az, cno, _) in lst:
            mark = "*" if svid in used else " "
            cells.append(f"{mark}{svid:>3}:{cno if cno is not None else '--':>2}")
        L.append(f"   {name:<8}({len(used):>2} used) " + " ".join(cells[:12]))
        for i in range(12, len(cells), 12):
            L.append(" " * 23 + " ".join(cells[i:i + 12]))
    c = st.cno_stats()
    if c:
        L.append(f" C/N0 dBHz  : max {c['max']}  mean {c['mean']:.1f}  top-4 mean {c['top4']:.1f}"
                 f"   (* = used in fix)")
    ps = position_stats(st.fixes)
    if ps:
        L.append(f" Position stats ({ps['n']} samples): CEP50 {ps['cep50']:.2f} m  CEP95 {ps['cep95']:.2f} m  "
                 f"2DRMS {ps['drms2']:.2f} m  max {ps['max']:.2f} m  alt std {fmt(ps['alt_std'], '.2f')} m")
    L.append(f" Messages   : " + "  ".join(f"{k}:{v}" for k, v in sorted(st.msg_count.items())))
    L.append(f" Checksum errors: NMEA {parser.nmea_bad}  UBX {parser.ubx_bad}")
    if st.txt:
        L.append(" TXT        : " + " | ".join(st.txt[-3:]))
    return "\n".join(L)


def summary(st, parser):
    L = ["", "========== TEST RESULT =========="]
    L.append(f" Run time        : {time.monotonic() - st.t0:.0f} s, {st.epochs} epochs")
    L.append(f" TTFF            : {fmt(st.ttff, '.1f')} s")
    L.append(f" Checksum errors : NMEA {parser.nmea_bad}, UBX {parser.ubx_bad}")
    ps = position_stats(st.fixes)
    if ps:
        L.append(f" Mean position   : {ps['lat']:.7f}, {ps['lon']:.7f}, alt {fmt(ps['alt'], '.2f')} m")
        L.append(f" Stability       : CEP50 {ps['cep50']:.2f} m, CEP95 {ps['cep95']:.2f} m, "
                 f"2DRMS {ps['drms2']:.2f} m, max {ps['max']:.2f} m, alt std {fmt(ps['alt_std'], '.2f')} m")
    else:
        L.append(" Not enough fixes for position statistics.")
    c = st.cno_stats()
    if c:
        L.append(f" Last C/N0       : {c['n']} signals, max {c['max']}, top-4 mean {c['top4']:.1f} dBHz")
    if st.mon_ver:
        L.append(" Firmware        : " + " | ".join(st.mon_ver))
    return "\n".join(L)


# ---------------------------------------------------------------- serial
def list_ports():
    return list(serial.tools.list_ports.comports())


def probe(port, baud, secs=1.5):
    try:
        with serial.Serial(port, baud, timeout=0.2) as s:
            p = StreamParser()
            ok = 0
            end = time.monotonic() + secs
            while time.monotonic() < end:
                for kind, _ in p.feed(s.read(512)):
                    ok += 1
                if ok >= 3:
                    return True
    except serial.SerialException as e:
        print(f"  {port}: {e}")
        return None
    return False


def autodetect(port, baud):
    ports = [port] if port else [p.device for p in list_ports()]
    bauds = [baud] if baud else BAUDS
    for pt in ports:
        for b in bauds:
            print(f"  trying {pt} @ {b} ...", end=" ", flush=True)
            r = probe(pt, b)
            print("OK" if r else "no data")
            if r:
                return pt, b
            if r is None:
                break
    return None, None


# ---------------------------------------------------------------- main
CSV_HEADER = ["pc_time", "utc_date", "utc_time", "quality", "fix_type", "sv_used", "sv_visible",
              "hdop", "pdop", "vdop", "lat", "lon", "alt_msl", "speed_kmh", "course",
              "hacc_m", "vacc_m", "cno_max", "cno_top4"]


def csv_row(st):
    c = st.cno_stats() or {}
    p = st.pvt or {}
    return [datetime.now().isoformat(timespec="milliseconds"), st.date, st.utc, st.quality,
            st.fix_type, st.num_sv_used, len({(k[0], k[1]) for k in st.visible_sats()}),
            st.hdop, st.pdop, st.vdop,
            None if st.lat is None else f"{st.lat:.8f}", None if st.lon is None else f"{st.lon:.8f}",
            st.alt, None if st.speed_kmh is None else round(st.speed_kmh, 3), st.course,
            p.get("hacc"), p.get("vacc"), c.get("max"),
            None if not c else round(c["top4"], 1)]


def main():
    ap = argparse.ArgumentParser(description="NEO-M9N GPS parameter test over UART")
    ap.add_argument("-p", "--port", help="COM port, e.g. COM5 (default: auto-detect)")
    ap.add_argument("-b", "--baud", type=int, help="baud rate (default: auto-detect, NEO-M9N = 38400)")
    ap.add_argument("-t", "--time", type=float, default=0, help="test duration in seconds, 0 = until Ctrl+C")
    ap.add_argument("--reset", choices=["cold", "warm", "hot"], help="send CFG-RST to measure TTFF")
    ap.add_argument("--no-ubx", action="store_true", help="do not enable UBX-NAV-PVT (NMEA only)")
    ap.add_argument("--csv", default=None, help="per-epoch CSV log (default gps_YYYYmmdd_HHMMSS.csv)")
    ap.add_argument("--raw", help="save the raw byte stream (opens in u-center)")
    ap.add_argument("--replay", help="read a raw log file instead of a COM port")
    ap.add_argument("--list", action="store_true", help="list COM ports and exit")
    args = ap.parse_args()

    os.system("")  # enable ANSI escape codes in the Windows console

    if args.replay:
        src = open(args.replay, "rb")
        port_desc = f"replay {args.replay}"
        ser = None
    else:
        if serial is None:
            sys.exit("pyserial is missing. Run setup.bat (or: pip install pyserial)")
        if args.list:
            for p in list_ports():
                print(f"{p.device:8} {p.description}")
            return
        print("Searching for GPS ...")
        port, baud = autodetect(args.port, args.baud)
        if not port:
            sys.exit("No valid NMEA/UBX data received. Check TX/RX wiring, power and baud rate.\n"
                     "Available ports: " + ", ".join(p.device + " (" + p.description + ")" for p in list_ports()))
        ser = serial.Serial(port, baud, timeout=0.1)
        port_desc = f"{port} @ {baud}"

    st = GnssState()
    parser = StreamParser()
    raw = open(args.raw, "wb") if args.raw else None
    csv_path = args.csv or datetime.now().strftime("gps_%Y%m%d_%H%M%S.csv")
    csv_f = open(csv_path, "w", newline="")
    wr = csv.writer(csv_f)
    wr.writerow(CSV_HEADER)

    if ser:
        ser.write(UBX_MON_VER_POLL)
        if not args.no_ubx:
            ser.write(ubx_valset_u1(KEY_MSGOUT_NAV_PVT_UART1, 1))
        if args.reset:
            time.sleep(0.3)
            ser.write(ubx_reset(args.reset))
            ser.flush()
            st.restart_ttff()
            print(f"{args.reset} start sent, measuring TTFF ...")
            time.sleep(1.0)
            if not args.no_ubx:  # GNSS-only reset keeps RAM config, resend to be safe
                ser.write(ubx_valset_u1(KEY_MSGOUT_NAV_PVT_UART1, 1))

    last_draw = 0.0
    try:
        while True:
            data = ser.read(4096) if ser else src.read(512)
            if not ser and not data:
                break
            if raw and data:
                raw.write(data)
            for kind, msg in parser.feed(data):
                if kind == "NMEA":
                    st.handle_nmea(msg)
                else:
                    st.handle_ubx(*msg)
            if st.new_epoch:
                st.new_epoch = False
                wr.writerow(csv_row(st))
            now = time.monotonic()
            if ser and now - last_draw >= 0.5:
                last_draw = now
                sys.stdout.write("\x1b[H\x1b[J" + render(st, parser, port_desc) + "\n")
                sys.stdout.flush()
            if args.time and now - st.t0 >= args.time:
                break
    except KeyboardInterrupt:
        pass
    except (serial.SerialException if serial else OSError) as e:
        print(f"\nCOM port error: {e}")
    finally:
        if ser:
            ser.close()
        if raw:
            raw.close()
        csv_f.close()
    if not ser:
        print(render(st, parser, port_desc))
    print(summary(st, parser))
    print(f" CSV log         : {os.path.abspath(csv_path)}")
    if args.raw:
        print(f" Raw log         : {os.path.abspath(args.raw)}")


if __name__ == "__main__":
    main()
