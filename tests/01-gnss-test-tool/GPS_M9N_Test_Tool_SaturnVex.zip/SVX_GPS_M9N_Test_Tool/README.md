# SVX-GPS-M9N-001 – GNSS Test Tool for Windows

## Folder contents
| File | Purpose |
|---|---|
| `gps_test.py` | Test script: reads NMEA/UBX from the module and shows GPS parameters |
| `setup.bat` | One-time setup: Python check/install + pyserial install |
| `run.bat` | Runs the test (auto-installs pyserial if missing) |
| `pkgs/pyserial-3.5-py2.py3-none-any.whl` | Bundled pyserial, installed **offline** – no Internet needed |
| `LICENSE.txt` / `NOTICE.txt` | BSD-3-Clause license of the SaturnVex files / third-party notices |

## Hardware
- SVX-GPS-M9N-001 board (u-blox NEO-M9N) with an active GPS antenna on the U.FL connector (RF1).
- A USB-UART adapter with **3.3 V logic levels** (CP2102, CH340, FT232, …).

Wire it to header H2:

| H2 | Signal | USB-UART |
|---|---|---|
| 5 | UART_TX (module output) | **RX** |
| 7 | UART_RX (module input) | **TX** |
| 9 (or 2) | GND | GND |
| 1 (or 3) | VIN, max 5.5 V | 5V |

> D_SEL is pulled up to 3V3, so the module talks over UART. V_USB is tied to GND, so the module's USB port is **not** used.

## Setup on a fresh PC (once)

### Step 1 – USB-UART driver
Plug in the USB-UART adapter and open **Device Manager** (`Win + X` → Device Manager). Look under **Ports (COM & LPT)**:
- If you see something like `USB-SERIAL CH340 (COM5)` or `Silicon Labs CP210x (COM5)`, the driver is installed. Note the COM number.
- If the device shows a yellow **!** under *Other devices*, install the driver:
  - CH340/CH341: https://www.wch-ic.com/downloads/CH341SER_EXE.html
  - CP210x: https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers
  - FT232: https://ftdichip.com/drivers/vcp-drivers/

  Then unplug and re-plug the adapter.

### Step 2 – Extract the package
Extract `GPS_M9N_Test_Tool_SaturnVex.zip` on the PC and keep the `SVX_GPS_M9N_Test_Tool` folder complete, **including the `pkgs` subfolder**.

### Step 3 – Install Python and pyserial
Double-click **`setup.bat`**.
- If Python is missing, it installs Python 3.12 via `winget`. When that finishes, **close the window and run `setup.bat` again**.
- The second run installs pyserial from `pkgs` (no Internet needed) and lists the COM ports.

If the PC has no `winget` (older Windows 10), install Python manually:
1. Download the Windows installer (64-bit) from https://www.python.org/downloads/windows/
2. In the installer, **tick "Add python.exe to PATH"**, then click *Install Now*.
3. Run `setup.bat` again.

> pyserial is bundled, but the Python installer is not. To make setup fully offline, copy the Python installer `.exe` along with the folder.

## Running the test
1. Power the board. Place the antenna with a clear view of the sky (outdoors or right at a window).
2. Double-click **`run.bat`**. The script auto-detects the COM port and baud rate (NEO-M9N default is 38400).
3. Press **Ctrl+C** to stop. The script prints a summary and saves a CSV file in the tool folder.

Options (from a Command Prompt opened in the tool folder):

```
run.bat -p COM5 -b 38400             :: specify COM port and baud rate
run.bat -p COM5 --reset cold         :: measure cold-start TTFF (also warm / hot)
run.bat -p COM5 -t 600 --raw log.ubx :: run 10 minutes, save raw stream (opens in u-center)
run.bat --replay log.ubx             :: re-analyse a saved raw file
run.bat --list                       :: list COM ports
```

## What the test shows
- UTC date/time, fix type (2D/3D), TTFF
- Latitude, longitude, altitude, speed, course
- PDOP / HDOP / VDOP
- hAcc / vAcc / sAcc / tAcc from UBX-NAV-PVT (enabled in RAM only, flash untouched; disable with `--no-ubx`)
- Satellites used / visible per constellation (GPS, GLONASS, Galileo, BeiDou) with C/N0 per satellite; `*` = used in fix
- Position stability with the board stationary: CEP50, CEP95, 2DRMS, altitude std-dev
- Checksum errors, message counts, firmware version (UBX-MON-VER)
- One CSV row per epoch in `gps_YYYYmmdd_HHMMSS.csv`

## Typical good results (antenna outdoors)
| Parameter | Good value |
|---|---|
| Cold-start TTFF | about 25–30 s |
| Hot-start TTFF | about 1–2 s |
| Satellites used | ≥ 12 |
| Top-4 mean C/N0 | ≥ 40 dBHz |
| HDOP | < 1.5 |
| hAcc | < 2.5 m |
| Checksum errors | 0 |

## Troubleshooting
| Symptom | Check |
|---|---|
| `No valid NMEA/UBX data received` | Swap TX/RX; check GND and VIN; confirm the COM port; close u-center or any other program using that port |
| `'py' / 'python' is not recognized` | Python is not on PATH → reinstall and tick *Add python.exe to PATH* |
| `Access is denied` / `PermissionError` | The COM port is held by another program |
| Data arrives but stays `No fix`, low C/N0 (< 30) | Antenna indoors or U.FL not seated; check active-antenna supply via L2/R4 |
| Many checksum errors | Long/noisy wires, or wrong logic level (5 V USB-UART) |
| Garbled characters on screen | Use Windows Terminal or the Windows 10+ cmd console |

---
SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Python and pyserial keep their own licenses (`NOTICE.txt`).

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com
