@echo off
REM SPDX-License-Identifier: BSD-3-Clause
REM Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
REM Run the GPS test. Arguments are passed through, e.g.:  run.bat -p COM5 --reset cold
cd /d "%~dp0"
set PY=python
where py >nul 2>nul && set PY=py -3

REM Install pyserial from the bundled pkgs folder if it is missing
%PY% -c "import serial" >nul 2>nul || (
    echo pyserial not found, installing from the pkgs folder ...
    %PY% -m pip install --disable-pip-version-check --no-index --find-links "%~dp0pkgs" pyserial
)

%PY% gps_test.py %*
pause
